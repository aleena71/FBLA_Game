var arrow;
var board;
//var target;
//var bulleyes;
var fly;
var points = 0;
var bl;
var br;

function setup() {
    createCanvas(400, 600);
    board = createSprite(200, 100, 100, 25);
    board.shapeColor = color(0, 0, 0);
    board.setCollider('rectangle', 0, 0, 100, 25);
    //target = createSprite(200, 100, 50, 25);
    //target.shapeColor = color(255, 0, 0);
    //target.setCollider('rectangle', 0, 0, 50, 25);
    //bulleyes = createSprite(200, 100, 25, 25);
    //bulleyes.shapeColor = color(0, 0, 255);
    arrow = createSprite(200, 500, 10, 100);
    arrow.shapeColor = color(255, 0, 0);
    bl = false;
    br = true;
    fly = false;
}

function draw() {
    background(255);
    noStroke();

    switch (points) {
        case 0:
            //red
            board.shapeColor = color(255, 0, 0);
            break;
        case 1:
            //orange
            board.shapeColor = color(255, 165, 0);
            break;
        case 2:
            //yellow
            board.shapeColor = color(255, 255, 0);
            break;
        case 3:
            //green
            board.shapeColor = color(0, 255, 0);
            break;
        case 4:
            //blue
            board.shapeColor = color(0, 0,2550);
            break;
        default:
            //purple
            board.shapeColor = color(128, 0, 128);
            break;
    }

    if (br) {
        board.position.x += 5;
        if (board.position.x == 350) {
            br = false;
            bl = true;
        }
    } else if (bl) {
        board.position.x -= 5;
        if (board.position.x == 50) {
            br = true;
            bl = false;
        }
    }

    if (keyDown(65) && fly == false) {
        arrow.position.x -= 8;
    }
    if (keyDown(68) && fly == false) {
        arrow.position.x += 8;
    }
    if (keyDown(87)) {
        fly = true;
    }
    if (fly) {
        arrow.position.y -= 10;
        if (arrow.position.y < 0) {
                arrow.remove();
                board.remove();
                setup();
        }
    }

    arrow.collide(board, function() {
        board.remove();
        arrow.remove();
        points += 1;
        console.log("finally");
        setup();
    })

    drawSprites();
}
