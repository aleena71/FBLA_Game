var gps = encodeURI("222 W 38th St, New York");

var url = "http://maps.googleapis.com/maps/api/staticmap?center=" + gps + "&zoom=17&scale=false&size=600x600&maptype=roadmap&key=AIzaSyDJXU9P8ieyia_jPLo26RSrj4tx7Kq1rg4&format=png&visual_refresh=true";

var url = url + "&markers=icon:http://img.informer.com/icons/png/48/4370/4370845.png%7Cshadow:false%7C" + gps;

var pokemons = ["&markers=icon:http://orig05.deviantart.net/4dcb/f/2012/302/8/6/pikachu_sprite_by_pokedan1-d5j3am9.png%7Cshadow:false%7C", "&markers=icon:http://plldh.net/media/pokemon/gen3/rusa/001.png%7Cshadow:false%7C", "&markers=icon:http://megaicons.net/static/img/icons_sizes/388/1147/64/007-squirtle-icon.png%7Cshadow:false%7C", "&markers=icon:http://megaicons.net/static/img/icons_sizes/388/1147/64/150-mewtwo-icon.png%7Cshadow:false%7C", "&markers=icon:http://megaicons.net/static/img/icons_sizes/388/1147/64/004-charmander-icon.png%7Cshadow:false%7C", "&markers=icon:http://kazukitzhacks.weebly.com/uploads/2/0/5/2/2052206/9024410.png%7Cshadow:false%7C"];   

var pokestop = ["500 7th Ave, New York", "501 7th Ave, New York", "1412 Broadway, New York", "225 W 35th St, New York", "225 W 37th St, New York", "520 8th Ave, New York", "1372 Broadway, New York", "535 7th Ave, New York", "200 W 40th St, New York", "250 W 40th St #1, New York"];

for (var i = 0; i < pokestop.length; i++) {
    url = url + pokemons[Math.round(Math.random() * (pokemons.length - 1))] + pokestop[i];
}

$('img').attr('src', url);
