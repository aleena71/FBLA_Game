var total1bl;
var total2bl;
var total3bl;
var totalgr;

var level = 1;

var x;
var y;



function setup() {
	createCanvas(600, 600);
	loadPixels();
	total1bl = 735000;
	total2bl = 577500;
	total3bl = 658500;
	totalgr = 2500;
	x = 125;
    y = 435;
}

function draw() {
	// background
	background(0, 0, 0);
	noStroke();

	// level generator
	if (level == 1) {
		level1();
	} else if (level == 2) {
		level2();
	} else if (level == 3) {
		level3();
	} else {
		// winning screen
		background(0);
	    fill(255, 255, 255);
	    textSize(50);
	    textAlign(CENTER , CENTER);
	    text("You Win!", 300, 300);
	    textFont("Courier");
	    rect(144,330,300,10);
		noLoop();
		// add button
	}

	// Player
	if (level < 4) {
		fill(255, 10, 10)
    	rect(x, y, 25, 25);
	}

	// player movement
    if (keyIsDown(UP_ARROW)) {
		y = y - 5;
	}
	if (keyIsDown(DOWN_ARROW)) {
		y = y + 5;
	}
	if (keyIsDown(LEFT_ARROW)) {
		x = x - 5;
	}
	if (keyIsDown(RIGHT_ARROW)) {
		x = x + 5;
	}

	// death detection
	if (level == 1) {
		var a = death(total1bl);
		if (a == 1) {
			x = 125;
			y = 435;
		} else if (a == 2) {
			level = 2;
		}
	} else if (level == 2) {
		var b = death(total2bl);
		if (b == 1) {
			x = 325;
			y = 75;
		} else if (b == 2) {
			level = 3;
		}
	} else if (level == 3) {
		var c = death(total3bl);
		if (c == 1) {
			x = 215;
			y = 460;
		} else if (c == 2) {
			level = 4;
		}
	}
}

var death = function(total) {
	loadPixels();
	if (sum(pixels, 0) < total) {
		console.log("loser");
		return 1;
	}
	if (sum(pixels, 200) < totalgr && level < 3) {
		console.log("winner");
		return 2;
	} else if (sum(pixels, 200) < 900) {
		console.log("winner");
		return 2;
	}
}

var sum = function(anArray, num){
  var count = 0;
  for (var i = 0; i < anArray.length; i++){
    if (anArray[i]==num) {
      count+=1;
    }
  }
  return count;
}

var level1 = function() {
	fill(255);
	rect(100, 400, 400, 100);
	rect(400, 300, 100, 100);
	rect(100, 200, 400, 100);
	rect(100, 100, 100, 100);
	rect(100, 50, 300, 50);
	fill(10, 200, 10);
	rect(350, 50, 50, 50);
}

var level2 = function() {
	fill(255);
	rect(300, 50, 50, 100);
	rect(350, 50, 200, 100);
	rect(500, 150, 50, 50);
	rect(300, 200, 250, 100);
	rect(300, 300, 100, 50);
	rect(300, 350, 250, 100);
	rect(500, 450, 50, 50);
	rect(400, 500, 150, 50);
	rect(300, 450, 50, 100);
	rect(100, 150, 200, 100);
	rect(150, 250, 50, 100);
	rect(100, 300, 50, 50);
	rect(150, 350, 50, 150);
	rect(250, 500, 50, 50);
	rect(200, 50, 50, 100);
	rect(50, 50, 100, 50);
	rect(50, 100, 50, 100);
	rect(50, 300, 50, 250);
	rect(100, 500, 50, 50);
	fill(10, 200, 10);
	rect(200, 450, 50, 50);
}

var level3 = function() {
	fill(255);
	rect(200, 450, 200, 100);
	rect(400, 400, 150, 100);
	rect(150, 300, 50, 200);
	rect(50, 400, 100, 50);
	rect(50, 450, 50, 50);
	rect(200, 300, 100, 50);
	rect(250, 250, 100, 200);
	rect(350, 250, 50, 50);
	rect(450, 200, 100, 200);
	rect(400, 50, 50, 200);
	rect(250, 50, 150, 100);
	rect(250, 150, 50, 50);
	rect(200, 200, 100, 40);
	rect(100, 200, 100, 40);
	rect(100, 50, 30, 150);
	rect(130, 50, 70, 30);
	fill(10, 200, 10);
	rect(170, 80, 30, 30);
}
