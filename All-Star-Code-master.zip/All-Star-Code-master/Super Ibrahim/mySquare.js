var x = 0;
var appear = true;
var dx = 5;

function setup() {
	createCanvas(500, 500);
}
	
function draw() {
	background(0, 0, 0);
	rectMode(CENTER);
	rect(x, 250, 200, 200);
	x+=dx;
	if (x > width / 2 && stop) {
		
		var myBtn = document.createElement('button');
		myBtn.textContent = "Change direction!";
		$('body').append(myBtn);
		stop = false;
	}

	$('button').click(changeDxn);
}

function changeDxn() {
	dx = -dx;
}