var makerurl = "https://maker.ifttt.com/trigger/spotify/with/key/c6RX5m2sFdOp-OPXbwK-SX";

function submitIt() {
    var message = $("#message").val();
    var img = $("#imgURL").val();

    var sendoff = {
        "value1" : message,
        "value2" : img,
    }
    $.post(makerurl, sendoff);

    $("#message").val("");
    $("#imgURL").val("");
}
